#Stephen Kleimeyer
#Files exercise 1, read numbers from file and print sum
with open("numbers.txt","r") as numbersFile:
    contents=numbersFile.read()
    contents=contents.strip()
    numsList=[int(x) for x in contents.split()]
    numsSum=sum(numsList)
print("EXERCISE 1 OF PYTHON FILES, READ NUMBERS FROM TEXT FILE, PRINT THE SUM.")
print("Here are the numbers from the text file:")
print(numsList)
print(f"The sum of the numbers is: {numsSum}")

