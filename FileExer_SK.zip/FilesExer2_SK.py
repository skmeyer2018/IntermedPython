#Stephen Kleimeyer
#Python Files Exercise 2, read text file, get word count, get letter count, print text vowels removed to another file.
#
#THIS FUNCTION REMOVES VOWELS FROM THE TEXT CONTENTS
def remove_vowels(contents):
    vowels=['a','e','i','o','u']
    letterList=list(contents) #EACH CHARACTER IN A LIST
    noVowels=[l if l not in vowels else '' for l in letterList ] #THEN USE LIST COMPREHENSION AND TERNARY CONDITIONAL TO FILTER OUT VOWELS
    vowelless="".join(noVowels) #THE NEW VOWEL-LESS CONTENTS IN A STRING
    return vowelless

#THIS FUNCTION FILTERS OUT PUNCTUATION MARKS BY RETAINING IN CONTENTS ALL LOWER AND UPPER CASE LETTERS.
#SPACES STILL NEEDED HERE FOR THE WORD SEPARATION AND COUNT.
def remove_punc(content):
    upper_cases="ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    all_case_alphabet=list(upper_cases + " " + upper_cases.lower()) #THE ENTIRE LIST OF UPPER AND LOWER CASE LETTERS AND ONE SPACE
    charList=list(content) #BREAK UP TEXT INTO A LIST OF INDIVIDUAL CHARACTERS AND SPACES
    filterPuncs=[l if l in all_case_alphabet else '' for l in charList] #FILTER OUT PUNCTUATION BY REPLACING WITH NULL CHARACTER
    puncless="".join(filterPuncs) #SAME TEXT WITHOUT PUNCTUATION
    return puncless

#READING THE FILE
with open("gettysburg.txt","r") as gettysburgText:
    contents=gettysburgText.read()
    contents=contents.strip()
    contents=remove_punc(contents)
    words=contents.split() #LIST OF SEPARATE WORDS
    wordCount=len(words) #TOTAL COUNT OF THE WORDS
    letterCount=sum([len(w) for w in words]) #COUNT ALL LETTERS WITHOUT SPACES BY SUMMING THE WORD LENGTHS
print("PROGRAM TO READ TEXT FROM FILE AND COUNT WORDS, COUNT LETTERS AND REMOVE VOWELS")
print("AND WRITE THE TEXT WITHOUT VOWELS TO A FILE.")
print()
print("This is the file from 'gettysburg.txt':")
print()
print(contents)
print()
print(f"The file contains {wordCount} words")
print(f"and {letterCount} letters.")
print()
print("Now removing vowels from the text and writing to a separate text file.")
#WRITING VOWEL-LESS TEXT TO A NEW FILE
with open("gettysburg_removed.txt","w") as vowellessText:
    vowellessContents=vowellessText.write(remove_vowels(contents))

print("Reading the vowelless results from the new file:")
print()
with open("gettysburg_removed.txt","r") as newVowelless:
    contents=newVowelless.read()
    contents=contents.strip()
    print(contents)
    


   
    
